#!/bin/bash

read -p "Enter the first number: " num1
read -p "Enter the second number: " num2

# Add the numbers
sum=$((num1 + num2))

# Print the result
echo "The sum of $num1 and $num2 is $sum"

