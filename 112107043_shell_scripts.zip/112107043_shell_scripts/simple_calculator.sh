#!/bin/bash

# Function to perform addition
addition() {
  local result=$(( $1 + $2 ))
  echo "The result of $1 + $2 is $result"
}

# Function to perform subtraction
subtraction() {
  local result=$(( $1 - $2 ))
  echo "The result of $1 - $2 is $result"
}

# Function to perform multiplication
multiplication() {
  local result=$(( $1 * $2 ))
  echo "The result of $1 * $2 is $result"
}

# Function to perform division
division() {
  local result=$(( $1 / $2 ))
  echo "The result of $1 / $2 is $result"
}

# Display menu
echo "Simple Calculator"
echo "-----------------"
echo "1. Addition"
echo "2. Subtraction"
echo "3. Multiplication"
echo "4. Division"
echo "5. Exit"

# Get the user's choice
read -p "Enter your choice: " choice

# Get the first number
read -p "Enter the first number: " num1

# Get the second number
read -p "Enter the second number: " num2

# Perform the corresponding operation based on the user's choice
case $choice in
  1) addition $num1 $num2;;
  2) subtraction $num1 $num2;;
  3) multiplication $num1 $num2;;
  4) division $num1 $num2;;
  5) exit;;
  *) echo "Invalid choice";;
esac

